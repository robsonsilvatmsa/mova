-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[RPAD] 

               (@SourceString VARCHAR(MAX), 

                @FinalLength  INT, 

                @PadChar      CHAR(1)) 

RETURNS VARCHAR(MAX) 

AS 

  BEGIN 

    RETURN 

      (SELECT @SourceString + Replicate(@PadChar,@FinalLength - Len(@SourceString))) 

  END

go

