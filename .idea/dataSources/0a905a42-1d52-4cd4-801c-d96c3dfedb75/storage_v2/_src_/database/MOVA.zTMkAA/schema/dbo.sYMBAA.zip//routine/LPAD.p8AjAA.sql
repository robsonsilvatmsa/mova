-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[LPAD] 

	-- Add the parameters for the function here
	(@SourceString VARCHAR(MAX), 

                @FinalLength  INT, 

                @PadChar      CHAR(1)) 

RETURNS VARCHAR(MAX) 
AS
BEGIN
	

	
    RETURN 

      (SELECT Replicate(@PadChar,@FinalLength - Len(@SourceString)) + @SourceString) 


	

END
go

